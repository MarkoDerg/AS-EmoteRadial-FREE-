fx_version 'adamant'
game 'gta5'
lua54 'yes'
version '1.0.0'

author 'MarkoTkm'
server_scripts {
	'config/config.lua',
	'server/server.lua',
}

client_scripts {
    'config/config.lua',
	'client/client.lua',
}

ui_page 'html/index.html'

files {
	"html/**/*.*",
}

dependencies {
    'es_extended',
}

escrow_ignore {
	'config/config.lua',
}
