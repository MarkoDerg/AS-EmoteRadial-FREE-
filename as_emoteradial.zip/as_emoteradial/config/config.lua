CFG_xMenu = {}

CFG_xMenu.Keybind = "U" -- Keybind

function startAnim(lib, anim)
	isPlaying = true
    ESX.Streaming.RequestAnimDict(lib, function()
		TaskPlayAnim(PlayerPedId(), lib, anim, 8.0, -8.0, -1, 1, 0, false, false, false)
	end)
end
RegisterNUICallback('action', function(data, cb)
    SetNuiFocus(false, false)
    if data.type == "animation-menu" then
        if data.action == 1 then
            startAnim('mp_ped_interaction', 'hugs_guy_a')
        elseif data.action == 2 then
            startAnim("random@arrests@busted", "idle_a")
        elseif data.action == 3 then
			startAnim('timetable@ron@ig_5_p3', 'ig_5_p3_base')
        elseif data.action == 4 then
            startAnim('amb@world_human_sunbathe@male@back@base', 'base')
        elseif data.action == 5 then
			local ply = PlayerPedId()
			ClearPedTasksImmediately(ply)
        elseif data.action == 6 then
            startAnim('anim@mp_player_intselfiethe_bird', 'idle_a')
        elseif data.action == 7 then
            startAnim('missbigscore2aig_3', 'wait_for_van_c')
			
        elseif data.action == 8 then
            startAnim("amb@world_human_leaning@male@wall@back@foot_up@idle_a", "idle_a")
        end
    end
end)

CFG_xMenu.Settings = {
	["Animation-Menu"] = {
		Action1 = {
			Label = "Umarmen",
			Image = "animation1.png",
		},
		Action2 = {
			Label = "Aufgeben",
			Image = "animation2.png",
		},
		Action3 = {
			Label = "Hinsetzen",
			Image = "animation3.png",
		},
		Action4 = {
			Label = "Sonnenbad",
			Image = "animation4.png",
		},
		Action5 = {
			Label = "Abbrechen",
			Image = "animation5.png",
		},
		Action6 = {
			Label = "Mittelfinger",
			Image = "animation6.png",
		},
		Action7 = {
			Label = "Ruhig warten",
			Image = "animation7.png",
		},
		Action8 = {
			Label = "Anlehnen",
			Image = "animation8.png",
		},
	},
}
