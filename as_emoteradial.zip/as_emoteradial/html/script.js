document.body.addEventListener('mousemove', onMouseMove);

const animation = document.querySelector('.animation');
const player = document.querySelector('.player');
const vehicle = document.querySelector('.vehicle');

show = false;
type = null
currentIndex = 0
currentType = null

anchorX = window.innerWidth / 2;
anchorY = window.pageYOffset + window.innerHeight;
vehicle.style.setProperty('--x', `${50}%`);
vehicle.style.setProperty('--y', `${100}%`);
vehicle.classList.add('on');

window.addEventListener("message", function(event) {
	var item = event.data;
	if (item.action == "open-animation-menu") {
		Action1 = item.Action1
		Action2 = item.Action2
		Action3 = item.Action3
		Action4 = item.Action4
		Action5 = item.Action5
		Action6 = item.Action6
		Action7 = item.Action7
		Action8 = item.Action8
		Action1_Image = item.Action1_Image
		Action2_Image = item.Action2_Image
		Action3_Image = item.Action3_Image
		Action4_Image = item.Action4_Image
		Action5_Image = item.Action5_Image
		Action6_Image = item.Action6_Image
		Action7_Image = item.Action7_Image
		Action8_Image = item.Action8_Image
		type = "animation-menu"
		anchorX = window.innerWidth / 2;
		anchorY = window.innerHeight / 2;
		animation.style.setProperty('--x', `${50}%`);
		animation.style.setProperty('--y', `${50}%`);
		animation.classList.add('on');
		show = true;
		$(".wrapper").show()
		$(".animation").show()
		$(".player").hide()
		$(".vehicle").hide()
		$("#animation-image1").css("background-image", "url(images/"+Action1_Image+'')
		$("#animation-image2").css("background-image", "url(images/"+Action2_Image+'')
		$("#animation-image3").css("background-image", "url(images/"+Action3_Image+'')
		$("#animation-image4").css("background-image", "url(images/"+Action4_Image+'')
		$("#animation-image5").css("background-image", "url(images/"+Action5_Image+'')
		$("#animation-image6").css("background-image", "url(images/"+Action6_Image+'')
		$("#animation-image7").css("background-image", "url(images/"+Action7_Image+'')
		$("#animation-image8").css("background-image", "url(images/"+Action8_Image+'')
	} else if (item.action == "open-player-menu") {
		Action1 = item.Action1
		Action2 = item.Action2
		Action3 = item.Action3
		Action4 = item.Action4
		Action1_Image = item.Action1_Image
		Action2_Image = item.Action2_Image
		Action3_Image = item.Action3_Image
		Action4_Image = item.Action4_Image
		type = "player-menu"
		anchorX = window.innerWidth / 2;
		anchorY = window.pageYOffset + window.innerHeight;
		player.style.setProperty('--x', `${50}%`);
		player.style.setProperty('--y', `${100}%`);
		player.classList.add('on');
		show = true;
		$(".wrapper").show()
		$(".animation").hide()
		$(".player").show()
		$(".vehicle").hide()
		$("#player-image1").css("background-image", "url(images/"+Action1_Image+'')
		$("#player-image2").css("background-image", "url(images/"+Action2_Image+'')
		$("#player-image3").css("background-image", "url(images/"+Action3_Image+'')
		$("#player-image4").css("background-image", "url(images/"+Action4_Image+'')
	} else if (item.action == "open-vehicle-menu") {
		Action1 = item.Action1
		Action2 = item.Action2
		Action3 = item.Action3
		Action4 = item.Action4
		Action1_Image = item.Action1_Image
		Action2_Image = item.Action2_Image
		Action3_Image = item.Action3_Image
		Action4_Image = item.Action4_Image
		type = "vehicle-menu"
		anchorX = window.innerWidth / 2;
		anchorY = window.pageYOffset + window.innerHeight;
		vehicle.style.setProperty('--x', `${50}%`);
		vehicle.style.setProperty('--y', `${100}%`);
		vehicle.classList.add('on');
		show = true;
		$(".wrapper").show()
		$(".animation").hide()
		$(".player").hide()
		$(".vehicle").show()
		$("#vehicle-image1").css("background-image", "url(images/"+Action1_Image+'')
		$("#vehicle-image2").css("background-image", "url(images/"+Action2_Image+'')
		$("#vehicle-image3").css("background-image", "url(images/"+Action3_Image+'')
		$("#vehicle-image4").css("background-image", "url(images/"+Action4_Image+'')
	}
  })


document.addEventListener("keyup", (event) => {
		$(".wrapper").hide()
		$.post(`http://${GetParentResourceName()}/action`, JSON.stringify({type:type, action:currentIndex}));
  return;
});


function onMouseMove({ clientX: x, clientY: y }) {
	let dx = x - anchorX;
	let dy = y - anchorY;
	let mag = Math.sqrt(dx * dx + dy * dy);
	let index = 0;
	if (show & type == "animation-menu") {
		$(".circle-svg").css("transition", "none")
		$(".circle-svg2").css("transition", "none")
	if (mag >= 100)  {
		let deg = Math.atan2(dy, dx) + 0.625 * Math.PI;
		while (deg < 0) deg += Math.PI * 2;
		index = Math.floor(deg / Math.PI * 4) + 1;
	}
	currentIndex = index
	animation.setAttribute('data-chosen', index);
	if (index) {
		$(".percent").show()
		$("#animation-item-name").show()
	} else {
		$(".percent").hide()
		$("#animation-item-name").hide()
		$(".inner-circle-image").css("background-image", "none")
	}

	if (index == 1) {
		currentIndex = index
		$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(339deg)');
		$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(339deg)');
		$(".inner-circle-image").css("background-image", "url(images/"+Action1_Image+'')
		$("#animation-item-name").text(Action1)
		} else if (index == 2) {
		$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(22deg)');
		$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(22deg)');
		$(".inner-circle-image").css("background-image", "url(images/"+Action2_Image+'')
		$("#animation-item-name").text(Action2)
		} else if (index == 3) {
		$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(69deg)');
		$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(69deg)');
		$(".inner-circle-image").css("background-image", "url(images/"+Action3_Image+'')
		$("#animation-item-name").text(Action3)
		} else if (index == 4) {
		$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(113deg)');
		$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(113deg)');
		$(".inner-circle-image").css("background-image", "url(images/"+Action4_Image+"")
		$("#animation-item-name").text(Action4)
		} else if (index == 5) {
		$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(159deg)');
		$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(159deg)');
		$(".inner-circle-image").css("background-image", "url(images/"+Action5_Image+'')
		$("#animation-item-name").text(Action5)
		} else if (index == 6) {
		$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(204deg)');
		$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(204deg)');
		$(".inner-circle-image").css("background-image", "url(images/"+Action6_Image+'')
		$("#animation-item-name").text(Action6)
		} else if (index == 7) {
		$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(248deg)');
		$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(248deg)');
		$(".inner-circle-image").css("background-image", "url(images/"+Action7_Image+'')
		$("#animation-item-name").text(Action7)
		} else if (index == 8) {
		$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(294deg)');
		$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(294deg)');
		$(".inner-circle-image").css("background-image", "url(images/"+Action8_Image+'')
		$("#animation-item-name").text(Action8)}

	} else if (show & type == "player-menu") {
		$(".circle-svg").css("transition", "all 0.24s ease-in-out")
		$(".circle-svg2").css("transition", "all 0.24s ease-in-out")
		if (mag >= 100)  {
			let deg = Math.atan2(dy, dx) + 0.998 * Math.PI;
			while (deg < 0) deg += Math.PI * 2;
			index = Math.floor(deg / Math.PI * 4) + 1;
		}
		currentIndex = index
		player.setAttribute('data-chosen', index);
		if (index) {
			$(".percent").show()
			$("#player-item-name").show()
		} else {
			$(".percent").hide()
			$("#player-item-name").hide()
			$(".inner-circle-image").css("background-image", "none")
		}

	if (index == 1) {
		currentIndex = index
		$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(-90deg)');
		$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(-90deg)');
		$(".inner-circle-image").css("background-image", "url(images/"+Action1_Image+'')
		$("#player-item-name").text(Action1)
		} else if (index == 2) {
		$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(-45deg)');
		$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(-45deg)');
		$(".inner-circle-image").css("background-image", "url(images/"+Action2_Image+'')
		$("#player-item-name").text(Action2)
		} else if (index == 3) {
		$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(-0.04deg)');
		$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(-0.04deg)');
		$(".inner-circle-image").css("background-image", "url(images/"+Action3_Image+'')
		$("#player-item-name").text(Action3)
		} else if (index == 4) {
		test = "right"
		$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(44.972deg)');
		$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(44.972deg)');
		$(".inner-circle-image").css("background-image", "url(images/"+Action4_Image+'')
		$("#player-item-name").text(Action4)
		}
	} else if (show & type == "vehicle-menu") {
		$(".circle-svg").css("transition", "all 0.24s ease-in-out")
		$(".circle-svg2").css("transition", "all 0.24s ease-in-out")
		if (mag >= 100)  {
			let deg = Math.atan2(dy, dx) + 0.998 * Math.PI;
			while (deg < 0) deg += Math.PI * 2;
			index = Math.floor(deg / Math.PI * 4) + 1;
		}
		currentIndex = index
		vehicle.setAttribute('data-chosen', index);
		if (index) {
			$(".percent").show()
			$("#vehicle-item-name").show()
		} else {
			$(".percent").hide()
			$("#vehicle-item-name").hide()
			$(".inner-circle-image").css("background-image", "none")
		}
		if (index == 1) {
			currentIndex = index
			$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(-90deg)');
			$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(-90deg)');
			$(".inner-circle-image").css("background-image", "url(images/"+Action1_Image+'')
			$("#vehicle-item-name").text(Action1)
			} else if (index == 2) {
			$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(-45deg)');
			$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(-45deg)');
			$(".inner-circle-image").css("background-image", "url(images/"+Action2_Image+'')
			$("#vehicle-item-name").text(Action2)
			} else if (index == 3) {
			$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(-0.04deg)');
			$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(-0.04deg)');
			$(".inner-circle-image").css("background-image", "url(images/"+Action3_Image+'')
			$("#vehicle-item-name").text(Action3)
			} else if (index == 4) {
			test = "right"
			$('.circle-svg').css('transform', 'translate(-50%, -50%) rotate(44.972deg)');
			$('.circle-svg2').css('transform', 'translate(-50%, -50%) rotate(44.972deg)');
			$(".inner-circle-image").css("background-image", "url(images/"+Action4_Image+'')
			$("#vehicle-item-name").text(Action4)
		}
	}
}